using UnityEngine;
using UnityEngine.Networking;
using System.Collections;
using System.Text;

public class SymbolicBridge : MonoBehaviour
{
    public string serverUrl = "http://localhost:5000/symbolic";

    public void SendSymbolicData(string json)
    {
        StartCoroutine(PostRequest(serverUrl, json));
    }

    IEnumerator PostRequest(string url, string json)
    {
        var request = new UnityWebRequest(url, "POST");
        byte[] bodyRaw = Encoding.UTF8.GetBytes(json);
        request.uploadHandler = new UploadHandlerRaw(bodyRaw);
        request.downloadHandler = new DownloadHandlerBuffer();
        request.SetRequestHeader("Content-Type", "application/json");

        yield return request.SendWebRequest();

        if (request.result == UnityWebRequest.Result.Success)
        {
            Debug.Log("Response: " + request.downloadHandler.text);
            // TODO: Handle symbolic response
        }
        else
        {
            Debug.LogError("Error: " + request.error);
        }
    }
}