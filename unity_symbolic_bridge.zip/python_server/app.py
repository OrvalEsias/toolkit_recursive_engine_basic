from flask import Flask, request, jsonify
from engine.symbolic_processor import process_symbolic_input

app = Flask(__name__)

@app.route('/symbolic', methods=['POST'])
def symbolic():
    data = request.json
    result = process_symbolic_input(data)
    return jsonify(result)

if __name__ == '__main__':
    app.run(debug=True)